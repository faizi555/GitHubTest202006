package com.cissst.service;

import java.util.List;

import com.cissst.entity.Inspection;

public interface IInspectionService {
	List<Inspection> findAllinspections();
	void save(Inspection i);
	Inspection findById(String id);
	void update(Inspection i);
	void delete(String id);
}
