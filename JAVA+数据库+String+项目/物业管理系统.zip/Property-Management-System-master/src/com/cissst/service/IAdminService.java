package com.cissst.service;

import java.util.List;

import com.cissst.entity.Admin;


public interface IAdminService {
	List<Admin> findAlladmins();
	void save(Admin a );
	
	Admin findById(String id);
	Admin findBynp(String name,String password);
	
	void update(Admin a );
	void delete(String id);
}
