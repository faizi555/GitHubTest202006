package com.cissst.service;

import java.util.List;

import com.cissst.entity.House;

public interface IHouseService {
	List<House> findAllHouse();
	List<House> findByOwnerid(String oid);
	House findById(String id);
	void add(House h);
	void delete(String id);
	void update(House h);
}
