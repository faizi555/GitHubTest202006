package com.cissst.dao;

import java.util.List;

import com.cissst.entity.Inspection;

public interface IInspectionDao {
	List<Inspection> getAllInspection();
	void save(Inspection i); 
	
	Inspection getInspectionById(String id);
	void update(Inspection i);
	
	void delete(String id);

}
