package com.cissst.dao;

import java.util.List;

import com.cissst.entity.Maintain;

public interface IMaintainDao {
	List<Maintain> getAllMaintain();
	void save(Maintain a); 
	Maintain getMaintainById(String id);
	List<Maintain> getMaintainByMaintainer(String maintainer);
	void update(Maintain a);
	void delete(String id);
}
