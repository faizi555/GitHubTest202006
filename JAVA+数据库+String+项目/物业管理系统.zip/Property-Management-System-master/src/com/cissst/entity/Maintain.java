package com.cissst.entity;

public class Maintain {
	private int id;
	private String thing;
	private String status;
	private String homesnumber;
	private String sdate;
	private String rdate;
	private Number tcost;
	private Number scost;
	private String maintainer;
	private String smemo;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getThing() {
		return thing;
	}
	public void setThing(String thing) {
		this.thing = thing;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHomesnumber() {
		return homesnumber;
	}
	public void setHomesnumber(String homesnumber) {
		this.homesnumber = homesnumber;
	}
	public String getSdate() {
		return sdate;
	}
	public void setSdate(String sdate) {
		this.sdate = sdate;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public Number getTcost() {
		return tcost;
	}
	public void setTcost(Number tcost) {
		this.tcost = tcost;
	}
	public Number getScost() {
		return scost;
	}
	public void setScost(Number scost) {
		this.scost = scost;
	}
	public String getMaintainer() {
		return maintainer;
	}
	public void setMaintainer(String maintainer) {
		this.maintainer = maintainer;
	}
	public String getSmemo() {
		return smemo;
	}
	public void setSmemo(String smemo) {
		this.smemo = smemo;
	}
	
	

}
