package com.cissst.entity;

public class Notice {
	private int id;
	private String content;
	private String ndate;
	private String title;
	private String uper;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getNdate() {
		return ndate;
	}
	public void setNdate(String ndate) {
		this.ndate = ndate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUper() {
		return uper;
	}
	public void setUper(String uper) {
		this.uper = uper;
	}

	}
